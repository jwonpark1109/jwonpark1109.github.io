import os
import ctypes
import subprocess
from nbt import nbt

ctypes.windll.kernel32.SetConsoleTitleW("J Tool Launcher v2.7")

# --- [1] 경로 설정 ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__)).strip()
PROJECT_ROOT = os.path.dirname(BASE_DIR) if os.path.basename(BASE_DIR).lower() == "launcher" else BASE_DIR
PROJECT_ROOT = os.path.normpath(PROJECT_ROOT)

DATA_DIR = os.path.join(PROJECT_ROOT, "data")
TOOLS_DIR = os.path.join(PROJECT_ROOT, "tools")
SYS_DATA_PATH = os.path.join(DATA_DIR, "sys-tool-data.dat")
SLOT_FILE_PATH = os.path.join(DATA_DIR, "slot-data.dat")

# --- [2] 유틸리티 및 ID 추출 ---
def get_nbt_safely(path):
    if not os.path.exists(path): return None
    try: return nbt.NBTFile(path, 'rb')
    except: return None

def get_actual_tool_id(nbt_obj):
    try:
        tid = nbt_obj["main"]["tool-data"]["tool id"]
        if str(tid).startswith("tool:"): return str(tid)
    except: pass
    def recursive_find(tag):
        if isinstance(tag, (nbt.TAG_Compound, nbt.NBTFile)):
            for k in tag:
                res = recursive_find(tag[k])
                if res: return res
        elif isinstance(tag, nbt.TAG_String) and str(tag).startswith("tool:"):
            return str(tag)
        return None
    return recursive_find(nbt_obj)

def load_tool_registry():
    registry = {}
    if not os.path.exists(TOOLS_DIR): return registry
    for root, dirs, files in os.walk(TOOLS_DIR):
        if "tool-data.dat" in files:
            n = get_nbt_safely(os.path.join(root, "tool-data.dat"))
            if n:
                tid = get_actual_tool_id(n)
                if tid: registry[tid] = root
    return registry

# --- [3] 슬롯 저장 로직 (slot /add) ---
def save_slot(num, tid):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        n_file = get_nbt_safely(SLOT_FILE_PATH)
        if not n_file:
            n_file = nbt.NBTFile(); n_file.name = "root"
            n_file["main"] = nbt.TAG_Compound(); n_file["main"]["data0"] = nbt.TAG_Compound()
            n_file["main"]["data0"]["slots"] = nbt.TAG_List(type=nbt.TAG_Compound)

        slots = n_file["main"]["data0"]["slots"]
        slot_key = f"slot:{num}"
        found = False
        for s in slots:
            if str(s["key"]) == slot_key:
                s["start"] = nbt.TAG_Compound(); s["start"]["tool_name"] = nbt.TAG_String(tid)
                found = True; break
        if not found:
            new_s = nbt.TAG_Compound(); new_s["key"] = nbt.TAG_String(slot_key)
            new_s["start"] = nbt.TAG_Compound(); new_s["start"]["tool_name"] = nbt.TAG_String(tid)
            slots.append(new_s)
        n_file.write_file(SLOT_FILE_PATH)
        print(f"[INFO]: slot save complete: {slot_key} -> {tid}")
    except Exception as e: print(f"[ERROR]: slot save filled: {e}")

# --- [4] 트리 실행 (오류 수정됨) ---
def run_tree_worker(mode=None):
    n = get_nbt_safely(SYS_DATA_PATH)
    if not n: return
    try:
        raw_path = str(n["Data"]["main"]["files"]["tree"]["tree.py"])
        clean_path = raw_path.replace(".\\J-tools\\", "").replace("./J-tools/", "").lstrip(".\\/")
        full_path = os.path.normpath(os.path.join(PROJECT_ROOT, clean_path)) # 오타 수정 완료
        
        if not os.path.exists(full_path):
            alt = full_path.replace("tree.py", "tool.py").replace("system-tool", "system-tools")
            if os.path.exists(alt): full_path = alt

        if os.path.exists(full_path):
            cmd = ["python", full_path]
            if mode: cmd.append(mode)
            print(f"[INFO]: starting: {full_path}")
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
            raw_out, _ = proc.communicate()
            try: out = raw_out.decode('utf-8')
            except: out = raw_out.decode('cp949', errors='ignore')
            print(f"\n{out.strip()}\n")
        else: print(f"[ERROR]: No found: {full_path}")
    except Exception as e: print(f"[ERROR]: tree start error: {e}")

# --- [5] 메인 루프 ---
if __name__ == "__main__":
    print(f"--- J-tools Launcher v2.7 ---")
    print(f"Type 'help' or '?' to see a list of commands.")
    while True:
        line = input("\nJ-tools > ").strip()
        if not line: continue
        parts = line.split()
        cmd = parts[0].lower()

        if cmd in ["help", "?", "？"]:
            print("\n  [ Command List ]")
            print("  tool /list, tool /start {id}")
            print("  slot /list, slot /add {n} {id}")
            print("  slot:{n}")
            print("  files /tree [/nbt, /data]\n")

        elif cmd == "tool":
            reg = load_tool_registry()
            if "/list" in parts:
                for tid in reg: print(f"  - {tid}")
            elif "/start" in parts and len(parts) >= 3:
                print(f"[INFO]: Starting Tool! Please Wait...")
                tid = parts[2]
                if tid in reg: subprocess.run([os.path.join(reg[tid], "tool.bat")], shell=True, cwd=reg[tid])
                else: print(f"[ERROR]: No Found ID: {tid}")

        elif cmd == "slot":
            if "/list" in parts:
                n = get_nbt_safely(SLOT_FILE_PATH)
                if n:
                    for s in n["main"]["data0"]["slots"]: print(f"  {s['key']} -> {s['start']['tool_name']}")
                else: print("[WARNING]: Slot is empty.")
            elif "/add" in parts and len(parts) >= 4:
                save_slot(parts[2], parts[3])

        elif cmd == "files" and "/tree" in line:
            mode = "--nbt" if "/nbt" in line else ("--data" if "/data" in line else None)
            run_tree_worker(mode)

        elif cmd.startswith("slot:"):
            n = get_nbt_safely(SLOT_FILE_PATH); reg = load_tool_registry()
            if n:
                for s in n["main"]["data0"]["slots"]:
                    if str(s["key"]) == cmd:
                        tid = str(s['start']['tool_name'])
                        if tid in reg: subprocess.run([os.path.join(reg[tid], "tool.bat")], shell=True, cwd=reg[tid])
                        else: print(f"[ERROR]: No Found Tool ID {tid}")
                        break

        elif cmd in ["exit", "quit"]: break
        else: print(f"[ERROR] : '{cmd}' is does not exist.")


