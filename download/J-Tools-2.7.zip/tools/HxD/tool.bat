title J Tool launcher
title start tool...
start HxD.exe
title J Tool launcher
exit