@echo off
echo Empty slot
pause
exit