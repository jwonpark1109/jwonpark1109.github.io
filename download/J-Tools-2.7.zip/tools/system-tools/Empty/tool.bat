@echo off
title J Tool launcher
title start tool...
echo [ERROR]: Error 404 No Found : No Found 'tool:Empty'
title J Tool launcher
exit