# tree.py
import os
import sys
from nbt import nbt

# 런처가 넘겨준 인자 확인
MODE_NBT = "--nbt" in sys.argv
MODE_DATA = "--data" in sys.argv

def scan_nbt(tag, prefix):
    results = []
    if isinstance(tag, nbt.TAG_Compound):
        for key, value in tag.items():
            results.append(f"{prefix}├── [NBT] {key}: {type(value).__name__}")
            if isinstance(value, (nbt.TAG_Compound, nbt.TAG_List)):
                results.extend(scan_nbt(value, prefix + "│   "))
    return results

def get_data_id(tag):
    if isinstance(tag, nbt.TAG_Compound):
        for k in tag:
            res = get_data_id(tag[k])
            if res: return res
    elif isinstance(tag, nbt.TAG_String) and str(tag).startswith("data:"):
        return str(tag)
    return None

def build_tree(path, prefix=""):
    lines = []
    try:
        entries = sorted(os.listdir(path))
        for i, entry in enumerate(entries):
            is_last = (i == len(entries) - 1)
            marker = "└── " if is_last else "├── "
            lines.append(f"{prefix}{marker}{entry}")
            
            full = os.path.join(path, entry)
            if os.path.isdir(full):
                lines.extend(build_tree(full, prefix + ("    " if is_last else "│   ")))
            elif entry.endswith(".dat"):
                try:
                    n_file = nbt.NBTFile(full, 'rb')
                    sub_prefix = prefix + ("    " if is_last else "│   ")
                    if MODE_NBT: lines.extend(scan_nbt(n_file, sub_prefix))
                    elif MODE_DATA:
                        did = get_data_id(n_file)
                        if did: lines.append(f"{sub_prefix}└── [ID] {did}")
                except: pass
    except: pass
    return lines

if __name__ == "__main__":
    # 프로젝트 루트 계산 (이 파일 위치 기준)
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    print("\n".join(build_tree(root)))
