@echo off
echo [INFO]: Your been kicked in this tool. Reason : 'Sorry! is a system tool. type 'files /tree'  to start this tool.'
exit