title J Tool launcher
title start tool...
start NBTExplorer.exe
title J Tool launcher
exit